/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ortprosto;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import static ortprosto.StudTestProccess.line;
import static ortprosto.StudTestProccess.names;

/**
 *
 * @author User
 */
public class StudChoice extends javax.swing.JFrame {

    
    
    public StudChoice() {
        initComponents();
    }
    
    public static int countLinesOld(String filename) throws IOException {
    InputStream is = new BufferedInputStream(new FileInputStream(filename));
    try {
        byte[] c = new byte[1024];
        int count = 0;
        int readChars = 0;
        boolean empty = true;
        while ((readChars = is.read(c)) != -1) {
            empty = false;
            for (int i = 0; i < readChars; ++i) {
                if (c[i] == '\n') {
                    ++count;
                }
            }
        }
        return (count == 0 && !empty) ? 1 : count;
    } finally {
        is.close();
    }
}
    
    
    static void a(String s)
    {
        try
       {
          File file = new File("ListOfLess.txt");
           if (!file.exists())
           {
               file.createNewFile();
           }
           FileWriter pw = new FileWriter(file, true);
           pw.write(s+"\n");

           pw.close();
       }
       catch(IOException e)
       {
           JOptionPane.showMessageDialog(null, "file is not open");
       }
    }
    

    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jScrollPane1.setViewportView(jList1);

        jButton1.setText("Выбрать тест");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Выйти");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        new StudMenu().setVisible(true);
        this.setVisible(false);
        //Это.датьВидимость(ложь);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (jList1.isSelectionEmpty()) {
             JOptionPane.showMessageDialog(null, "Выберите объек!");
        }
        else
            {
            boolean s = true;
            String line="00";
            BufferedReader bs = null;
            String as = "ListOfLess.txt";
            int col = 0;
            try {
                col = countLinesOld(as);
            } catch (IOException ex) {
                Logger.getLogger(StudChoice.class.getName()).log(Level.SEVERE, null, ex);
            }
           try
           {
              File file = new File(as);
               if (!file.exists())
               {
                   file.createNewFile();
               }

                bs = new BufferedReader(new FileReader(as));

                for (int i = 0; i < col; i++) {
                   line=bs.readLine();
                    if (line.equals(jList1.getSelectedValue())) {
                        //s=false;
                        break;
                    }
               }
               bs.close();
           }
           catch(IOException e)
           {
                JOptionPane.showMessageDialog(null, "file is not open");
           }
           if(s)
           {
               ConnectionDB conn = new ConnectionDB();

                    String inquiry = "alter table stud add column "+jList1.getSelectedValue()+" varchar(50);";
                    try
                    {
                        Statement statement = conn.getConnection().createStatement();
                        statement.executeQuery(inquiry);

                    }
                    catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
            String nameOf = jList1.getSelectedValue();
            a(nameOf);
           }









             try
           {
              File file = new File("NameOfTable.txt");
               if (!file.exists())
               {
                   file.createNewFile();
               }
               PrintWriter pw = new PrintWriter(file);
               pw.println(jList1.getSelectedValue());

               pw.close();
           }
           catch(IOException e)
           {
               JOptionPane.showMessageDialog(null, "file is not open");
           }
















             new StudTestProccess().setVisible(true);
             this.setVisible(false);
            }
        
        
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
         ConnectionDB conn = new ConnectionDB();
       String inquiry = "SELECT table_name\n" +
                        "FROM information_schema.tables\n" +
                        "WHERE table_schema = 'public'\n" +
                        "ORDER BY table_name;";
        try
        {
            Statement statement = conn.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(inquiry);
            DefaultListModel dlm = new DefaultListModel();
       
            while(resultSet.next())
            {
                dlm.addElement(resultSet.getString("table_name"));
                jList1.setModel(dlm);
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        
        
        
        
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudChoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudChoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudChoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudChoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudChoice().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
