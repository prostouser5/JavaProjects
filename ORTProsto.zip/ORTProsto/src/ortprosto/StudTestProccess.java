package ortprosto;


import java.io.*;
import static java.lang.Thread.sleep;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author User
 */
public class StudTestProccess extends javax.swing.JFrame {
static int l = 1;
static int i = 0;
static int miliseconds;
static int seconds = 0;
static int minutes = 5;
static boolean state = true;
static int start = 0;
static boolean time = false;
static int timeStart = 0;
static ArrayList<Integer> trueAnswer = new ArrayList<Integer>(100);
static int y = 0;
static ArrayList <String> ka1 = new ArrayList<>(100);



    public StudTestProccess() {
        initComponents();
    }
    

    
    
    
    static String line(String line)
    {
       BufferedReader bs = null;
       try
       {
          File file = new File("NameOfTable.txt");
           if (!file.exists())
           {
               file.createNewFile();
           }
            bs = new BufferedReader(new FileReader("NameOfTable.txt"));
            line=bs.readLine();
           bs.close();
           
       }
       catch(IOException e)
       {
            JOptionPane.showMessageDialog(null, "file is not open");
       }
       
       return line;
    }
    
    
    static String names(String line)
    {
        

       
       return line;
    }
    
     

    
    

    
    private static ArrayList getQues(ArrayList<String> ka )
    {
        
        String line = null;
        line = line(line);

       ConnectionDB conn = new ConnectionDB();
       String inquiry = "select questionfor from "+line+";";
        try
        {
            Statement statement = conn.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(inquiry);
            while(resultSet.next())
            {
                
                ka.add(resultSet.getString("questionfor"));
            }  
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
        return ka;
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        buttonGroup1.add(jRadioButton1);

        buttonGroup1.add(jRadioButton2);

        buttonGroup1.add(jRadioButton3);

        buttonGroup1.add(jRadioButton4);

        jButton1.setText("Предыдущий");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Завершить");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton4.setText("Следующий");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Timer 00:00");

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel2.setText("Вопрос № ");

        jLabel3.setText("     ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 8, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(208, 208, 208)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(201, 201, 201)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRadioButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRadioButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRadioButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(43, 43, 43)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(299, 299, 299)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(360, 360, 360))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton4)
                .addGap(29, 29, 29)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton4))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
        if(timeStart == 0)
        {
            for(int y = 0; y<100; y++)
            {
                trueAnswer.add(0);
                ka1.add("0");
            }
        }
        
        ArrayList <String> ka = new ArrayList<>(1);
        ka = getQues(ka);

        String line = null;
        line = line(line);
        
       ConnectionDB conn = new ConnectionDB();
       String inquiry = "select * from "+line+";";
        try
        {
            Statement statement = conn.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(inquiry);
            
            
           
            while(resultSet.next())
            {
                
                if(resultSet.getString("questionfor").equals(ka.get(i)))
                {
                    jLabel3.setText(resultSet.getString("result"));
                    jLabel3.setVisible(false);
                    jTextArea1.setText(resultSet.getString("questionfor"));
                    jRadioButton1.setText(resultSet.getString("res1"));
                    jRadioButton2.setText(resultSet.getString("res2"));
                    jRadioButton3.setText(resultSet.getString("res3"));
                    jRadioButton4.setText(resultSet.getString("res4"));
                    
                    
                    break;
                }
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        if(l==1)jButton1.setEnabled(false);
        else jButton1.setEnabled(true);

        if(l==ka.size()) jButton4.setEnabled(false);
        else jButton4.setEnabled(true);

        jLabel2.setText("Вопрос № "+(i+1));


        
        
        
        
                if(minutes<1&&seconds<1)
                     {
                        state = false;
                        jButton1.setEnabled(false);
                        jButton4.setEnabled(false);

                     }
        if (!time)
        {
                if(start==0)
                {
                    state = true;
                    Thread t = new Thread()
                    {
                        public void run()
                        {
                           for(;;)
                           {
                               if(state==true)
                               {
                                   
                                   try
                                   {
                                       sleep(1);
                                       if(miliseconds>600)
                                       {
                                           miliseconds = 0;
                                           seconds--;
                                       }
                                       if(seconds==-1)
                                       {
                                           miliseconds = 0;
                                           seconds = 59;
                                           minutes--;
                                       }

                                       if(minutes<1&&seconds<1&&miliseconds<1)
                                       {
                                           state = false;
                                       }
                                         miliseconds++;
                                         if(state == true) jLabel1.setText("Timer: "+minutes+" : "+seconds);
                                         else{ jLabel1.setText("Time Out!"); time = true;}
                                   }

                                   catch(Exception e) 
                                   {

                                   }
                               }
                               else
                               {
                                   break;
                               }
                           }
                        }
                    };
                    t.start();
                }
        }
        else jLabel1.setText("Time Out!");

    }//GEN-LAST:event_formWindowOpened
   
    
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        
       
        l++;

        String check = "0";
        if(jRadioButton1.isSelected())check = "1";
        else if(jRadioButton2.isSelected())check = "2";
        else if(jRadioButton3.isSelected())check = "3";
        else if(jRadioButton4.isSelected())check = "4";
        
        if(jLabel3.getText().equals(check)) trueAnswer.set(i, 1);
        else trueAnswer.set(i, 0);
        timeStart++;
        i++;
        ArrayList <String> ka = new ArrayList<>(100);
        ka = getQues(ka);
         
          
         ka1.set(y,"№ "+(y+1)+"\nВопрос: "+ka.get(y)+"\nВаш ответ: "+check+"\nПравильный ответ: "+jLabel3.getText()+";\n\n");
             y++;
        this.setVisible(false);
        new StudTestProccess().setVisible(true);
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        y--;
        l--;
        i--;
        
        this.setVisible(false);
        new StudTestProccess().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String check = null;
        if(jRadioButton1.isSelected())check = "1";
        if(jRadioButton2.isSelected())check = "2";
        if(jRadioButton3.isSelected())check = "3";
        if(jRadioButton4.isSelected())check = "4";
       
        if(jLabel3.getText().equals(check)) trueAnswer.set(i, 1);
        else trueAnswer.set(i, 0); 
        int resultend = 0;
        for (int j = 0; j < trueAnswer.size()-1; j++)
        {
            resultend = resultend + trueAnswer.get(j);
        }

        
        
        ArrayList <String> ka = new ArrayList<>(1);
         ka = getQues(ka);
        
        try
       {
          File file = new File("Results.txt");
           if (!file.exists())
           {
               file.createNewFile();
           }
           FileWriter pw = new FileWriter(file, true);
           int k=0;
           for(int u = 0; u<100; u++)
           {
               if(trueAnswer.get(u) == 1)
               {
                   k++;
               }
           }
           String line = null;
        line = line(line);
           String re = null;
           ConnectionDB conn = new ConnectionDB();
       String inquiry = "select count(*) from "+line+";";
        try
        {
            Statement statement = conn.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(inquiry);
            while(resultSet.next())
            {
                re = resultSet.getString("count");
            }

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

         ka1.set(y,"№ "+(y+1)+"\nВопрос: "+ka.get(y)+"\nВаш ответ: "+check+"\nПравильный ответ: "+jLabel3.getText()+";\n\nВы ответили верно на "+k+" из "+re);
         
         for(int h = 0; h <= y; h++)
         {
             pw.write(ka1.get(h));
         }
         
           pw.close();
       }
       catch(IOException e)
       {
           JOptionPane.showMessageDialog(null, "file is not open");
       }
        
        
        String names="",lastnames = "", informations="";
              BufferedReader bs = null;
       try
       {
          File file = new File("login.txt");
           if (!file.exists())
           {
               file.createNewFile();
           }
            bs = new BufferedReader(new FileReader("login.txt"));
            
            names = bs.readLine();
            lastnames = bs.readLine();
            informations = bs.readLine();
            
           bs.close();
           
       }
       catch(IOException e)
       {
            JOptionPane.showMessageDialog(null, "file is not open");
       }
        
         String line = null;
        line = line(line);    
        ConnectionDB conn = new ConnectionDB();
       String inquiry1 = "update stud set "+line+" = '"+resultend+" out of "+ka.size()+"' where name = '"+names+"' and lastname = '"+lastnames+"' and information = '"+informations+"';";
        System.out.println(inquiry1);
       try
        {
            Statement statement = conn.getConnection().createStatement();
            statement.executeQuery(inquiry1);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        i=0;
        l=1;
        timeStart = 0;
        y = 0;
        resultend = 0;
        for(int s = 0; s<100; s++)
            {
                trueAnswer.add(s,0);
                ka1.add(s,"0");
                
            }

        this.setVisible(false);
        new StudResultTest().setVisible(true);

    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudTestProccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudTestProccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudTestProccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudTestProccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudTestProccess().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
