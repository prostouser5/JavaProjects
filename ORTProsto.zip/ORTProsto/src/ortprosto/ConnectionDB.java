
package ortprosto;
import java.sql.*;

public class ConnectionDB {
    private final String HOST = "jdbc:postgresql://localhost:5432/project";
    private final String USERNAME = "tobos";
    private final String PASSWORD = "996705854655";
    
    private Connection connection;
    
    public ConnectionDB(){
        try
        {
            connection = DriverManager.getConnection(HOST, USERNAME,PASSWORD);
        }
        catch(SQLException e)
        {
            System.out.println("Не получилось!");
            e.printStackTrace();
        }
    }
    
    public Connection getConnection()
    {
        return connection;
    }
        
}
